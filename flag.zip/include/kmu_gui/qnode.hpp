/**
 * @file /include/rok3_qt_gui/qnode.hpp
 *
 * @brief Communications central!
 *
 * @date February 2011
 **/
/*****************************************************************************
** Ifdefs
*****************************************************************************/

#ifndef kmu_gui_QNODE_HPP_
#define kmu_gui_QNODE_HPP_

/*****************************************************************************
** Includes
*****************************************************************************/

// To workaround boost/qt4 problems that won't be bugfixed. Refer to
//    https://bugreports.qt.io/browse/QTBUG-22829
#ifndef Q_MOC_RUN
#include <ros/ros.h>
#endif
#include <string>
#include <QThread>
#include <QStringListModel>
#include <QImage>
#include <QLabel>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/Joy.h>
#include "kmu_gui/motor.h"
#include "kmu_gui/battery.h"
#include "kmu_gui/command.h"
#include "kmu_gui/joystick.h"

struct Motor{
    int HEADER_SEC;
    int HEADER_NSEC;
    std::string NAME;

    std::string CM;
    std::string RP;

    bool LMC_S;
    bool RMC_S;
    bool FMC_S;

    int LM_SPD;
    float LW_SPD;

    int RM_SPD;
    float RW_SPD;

    int FM_SPD;
    float FW_SPD;

    int FM_AGL;
    float FW_AGL;
};

struct Battery{
    int HEADER_SEC;
    int HEADER_NSEC;
    std::string NAME;

    float V;
    float A;

    unsigned int SOC;
    unsigned int TEMP;
};

struct Joystick{
    int HEADER_SEC;
    int HEADER_NSEC;;
    std::string NAME;

    double LS_X;
    double LS_Y;
    int L_T;

    bool L1_BTN;
    bool L2_BTN;
    bool L3_BTN;

    double RS_X;
    double RS_Y;
    int R_T;

    bool R1_BTN;
    bool R2_BTN;
    bool R3_BTN;

    double D_BTN_X;
    double D_BTN_Y;

    bool BTN0, BTN1, BTN2, BTN3;

    bool S_BTN;
    bool O_BTN;
    bool PS_BTN;

    bool DMC_BTN;
    bool FMC_BTN;
};

struct Movie{
    int cam_width;
    int cam_height;

    int rviz_width;
    int rviz_height;
};

/*****************************************************************************
** Namespaces
*****************************************************************************/

namespace kmu_gui {

  /*****************************************************************************
  ** Class
  *****************************************************************************/

  	class QNode : public QThread {
  		Q_OBJECT
  	public:
  		QNode(int argc, char** argv );
  		virtual ~QNode();
  		bool init();
  		bool init(const std::string &master_url, const std::string &host_url);
  		void run();
      void Camera_Callback(const sensor_msgs::ImageConstPtr &msg);
      void Rviz_Top_Callback(const sensor_msgs::ImageConstPtr &msg);
      void Rviz_Tpf_Callback(const sensor_msgs::ImageConstPtr &msg);
      void RtoC_M_Callback(const kmu_gui::motor& motor_msg);
      void RtoC_B_Callback(const kmu_gui::battery& battery_msg);
      void RtoC_J_Callback(const kmu_gui::joystick& joystick_msg);
      void CtoR_J_Callback(const sensor_msgs::Joy::ConstPtr& msg);

      /*********************
      ** Logging
      **********************/
  		enum LogLevel {
  			Debug,
  			Info,
  			Warn,
  			Error,
  			Fatal
  		};
      QImage view_image;
  		QStringListModel* loggingModel() { return &logging_model; }
  		void log( const LogLevel &level, const std::string &msg);

  		Q_SIGNALS:
  		void loggingUpdated();

      void motorflagUpdated();
      void batteryflagUpdated();
      void RtoC_joystickflagUpdated();
      void CtoR_joystickflagUpdated();
      void rosShutdown();
      void CameraUpdated(const QImage &);
      void Rviz_Top_Updated(const QImage &);
      void Rviz_Tpf_Updated(const QImage &);

      void mainWindowForceUpdate(const double);

  	private:
  		int init_argc;
  		char** init_argv;
      ros::Publisher rosmode_publisher;

      ros::Subscriber S_Camera_movie;
      ros::Subscriber S_top_movie;
      ros::Subscriber S_tpf_movie;
      ros::Subscriber S_Motor_data;
      ros::Subscriber S_Battery_data;
      ros::Subscriber S_RtoC_Joystick_data;
      ros::Subscriber S_CtoR_Joystick_data;
      ros::Time lastImgMsgTime;

        QStringListModel logging_model;
  	};



  }  // namespace kmu_gui

#endif /* kmu_gui_QNODE_HPP_ */
