/**
 * @file /src/main_window.cpp
 *
 * @brief Implementation for the qt gui.
 *
 * @date February 2011
 **/
/*****************************************************************************
** Includes
*****************************************************************************/

#include <QtGui>
#include <QMessageBox>
#include <iostream>
#include "../include/kmu_gui/main_window.hpp"
#include "../include/kmu_gui/qnode.hpp"

/*****************************************************************************
** Namespaces
*****************************************************************************/

extern Motor motor_data;
extern Battery battery_data;
extern Joystick RtoC_joystick_data;
extern Joystick CtoR_joystick_data;

extern Movie movie_data;

namespace kmu_gui {

        using namespace Qt;
        /*****************************************************************************
            ** Implementation [MainWindow]
            *****************************************************************************/

            MainWindow::MainWindow(int argc, char** argv, QWidget *parent)
                : QMainWindow(parent, Qt::FramelessWindowHint) // 상단바 없애기. (frameless)
            , qnode(argc,argv) {
                ui.setupUi(this); // Calling this incidentally connects all ui's triggers to on_...() callbacks in this class.
                QObject::connect(ui.actionAbout_Qt, SIGNAL(triggered(bool)), qApp, SLOT(aboutQt())); // qApp is a global variable for the application

                ReadSettings();
                setWindowIcon(QIcon(":/images/icon.png"));
                ui.tab_manager->setCurrentIndex(0); // ensure the first tab is showing - qt-designer should have this already hardwired, but often loses it (settings?).

                //ui.tab_manager->setStyleSheet("::tab {margin: 0px;}");
                QObject::connect(&qnode, SIGNAL(rosShutdown()), this, SLOT(close()));
                QObject::connect(&qnode, SIGNAL(mainWindowForceUpdate(const double)), this, SLOT(mainUIupdate(const double)));

                /*********************
                ** Logging
                **********************/
//                ui.view_logging->setModel(qnode.loggingModel()); //diff.sec, diff.nsec
                QObject::connect(&qnode, SIGNAL(CameraUpdated(const QImage &)),    this, SLOT(updateCameraView(const QImage &)));
                QObject::connect(&qnode, SIGNAL(Rviz_Top_Updated(const QImage &)), this, SLOT(updateRviz_topView(const QImage &)));
                QObject::connect(&qnode, SIGNAL(Rviz_Tpf_Updated(const QImage &)), this, SLOT(updateRviz_tpfView(const QImage &)));
                QObject::connect(&qnode, SIGNAL(motorflagUpdated()), this, SLOT(updateMotorDataView()));
                QObject::connect(&qnode, SIGNAL(batteryflagUpdated()), this, SLOT(updateBatteryDataView()));
                QObject::connect(&qnode, SIGNAL(RtoC_joystickflagUpdated()), this, SLOT(RtoC_updateJDataView()));
                QObject::connect(&qnode, SIGNAL(CtoR_joystickflagUpdated()), this, SLOT(CtoR_updateJDataView()));

                /*********************
                ** Auto Start
                **********************/
                if ( ui.comm_checkbox_remember_settings->isChecked() ) {
                    on_comm_connect_button_clicked(true);
                }

                /*********************
                ** Label
                **********************/

                m_lightimg[0].load(":/images/Red.png");
                m_lightimg[1].load(":/images/Green.png");

                m_switchimg[0].load(":/images/switch1.jpg");
                m_switchimg[1].load(":/images/switch2.jpg");

                //Main Tab
                ui.main_comm_delay_lcd->setNumDigits(5);
                ui.main_comm_speed_lcd->setNumDigits(5);
                ui.main_robotstatus_FW_AGL_lcd->setNumDigits(5);
/*
                ui.summary_LM_SPD_lcd->setNumDigits(10);
                ui.summary_LW_SPD_lcd->setNumDigits(10);
                ui.summary_FM_SPD_lcd->setNumDigits(10);
                ui.summary_FW_SPD_lcd->setNumDigits(10);
                ui.summary_RM_SPD_lcd->setNumDigits(10);
                ui.summary_RW_SPD_lcd->setNumDigits(10);
                ui.summary_FM_AGL_lcd->setNumDigits(10);
                ui.summary_FW_AGL_lcd->setNumDigits(10);
                ui.summary_voltage_lcd->setNumDigits(10);
                ui.summary_ampere_lcd->setNumDigits(10);
                ui.summary_temperature_lcd->setNumDigits(10);
*/

                ui.sensor_gps_latitude_lcd ->setNumDigits(10);
                ui.sensor_gps_longitude_lcd ->setNumDigits(10);
                ui.sensor_gps_altitude_lcd ->setNumDigits(10);
                ui.sensor_gps_time_lcd ->setNumDigits(10);
                ui.sensor_imu_angular_vel_x_lcd ->setNumDigits(10);
                ui.sensor_imu_angular_vel_y_lcd ->setNumDigits(10);
                ui.sensor_imu_angular_vel_z_lcd ->setNumDigits(10);
                ui.sensor_imu_linear_accel_x_lcd ->setNumDigits(10);
                ui.sensor_imu_linear_accel_y_lcd ->setNumDigits(10);
                ui.sensor_imu_linear_accel_z_lcd ->setNumDigits(10);

                ui.sensor_imu_quaternion_x_lcd ->setNumDigits(10);
                ui.sensor_imu_quaternion_y_lcd ->setNumDigits(10);
                ui.sensor_imu_quaternion_z_lcd ->setNumDigits(10);
                ui.sensor_imu_quaternion_w_lcd ->setNumDigits(10);

                ui.motor_header_sec_lcd ->setNumDigits(5);
                ui.motor_header_nsec_lcd ->setNumDigits(5);

                ui.motor_LM_SPD_lcd ->setNumDigits(5);
                ui.motor_LW_SPD_lcd ->setNumDigits(5);
                ui.motor_FM_SPD_lcd ->setNumDigits(5);
                ui.motor_FW_SPD_lcd ->setNumDigits(5);
                ui.motor_RM_SPD_lcd ->setNumDigits(5);
                ui.motor_RW_SPD_lcd ->setNumDigits(5);
                ui.motor_FM_AGL_lcd ->setNumDigits(5);
                ui.motor_FW_AGL_lcd ->setNumDigits(5);

                /*
                ui.battery_sec_lcd ->setNumDigits(5);
                ui.battery_nsec_lcd ->setNumDigits(5);
                ui.battery_voltage_lcd ->setNumDigits(5);
                ui.battery_ampere_lcd ->setNumDigits(5);
                ui.battery_temperature_lcd ->setNumDigits(5);
*/
                /*******************************
                ** Button test - explicit way
                ********************************/


            }

            MainWindow::~MainWindow() {}

            /*****************************************************************************
            ** Implementation [Slots]
            *****************************************************************************/

            void MainWindow::showNoMasterMessage() {
                QMessageBox msgBox;
                msgBox.setText("Couldn't find the ros master.");
                msgBox.exec();
                close();
            }

            void MainWindow::showButtonTestMessage() {
                QMessageBox msgBox;
                msgBox.setText("Button test ...");
                msgBox.exec();
                //close();
            }
            /*
             * These triggers whenever the button is clicked, regardless of whether it
             * is already checked or not.
             */

            void MainWindow::on_comm_connect_button_clicked(bool check ) {
                    if ( ui.comm_checkbox_use_environment->isChecked() ) {
                        if ( !qnode.init() ) {
                            showNoMasterMessage();
                        } else {
                            ui.comm_connect_button->setEnabled(false);
                        }
                    } else {
                        if ( ! qnode.init(ui.comm_connect_line_edit_master->text().toStdString(),
                            ui.comm_connect_line_edit_host->text().toStdString()) ) {
                            showNoMasterMessage();
                    } else {
                        ui.comm_connect_button->setEnabled(false);
                        ui.comm_connect_line_edit_master->setReadOnly(true);
                        ui.comm_connect_line_edit_host->setReadOnly(true);
                        ui.comm_connect_line_edit_topic->setReadOnly(true);
                    }
                }
            }

//            void MainWindow::on_button_test_clicked(bool check ) {
//                showButtonTestMessage();
//            }

            void MainWindow::on_comm_checkbox_use_environment_stateChanged(int state) {
                bool enabled;
                if ( state == 0 ) {
                    enabled = true;
                } else {
                    enabled = false;
                }
                ui.comm_connect_line_edit_master->setEnabled(enabled);
                ui.comm_connect_line_edit_host->setEnabled(enabled);
                //ui.line_edit_topic->setEnabled(enabled);
            }

            /*****************************************************************************
            ** Implemenation [Slots][manually connected]
            *****************************************************************************/

            /**
             * This function is signalled by the underlying model. When the model changes,
             * this will drop the cursor down to the last line in the QListview to ensure
             * the user can always see the latest log message.
             */

            void MainWindow::mainUIupdate(const double rosTimeDiff_byImg){
                ui.main_comm_delay_lcd->display(rosTimeDiff_byImg);
                //sstd::cout<<rosTimeDiff_byImg<<std::endl;
            }


            void MainWindow::updateCameraView(const QImage &msg) {
                ui.main_camera->setPixmap(QPixmap::fromImage(msg));
//                QPixmap p = QPixmap::fromImage(msg);
            }

            void MainWindow::updateRviz_topView(const QImage &msg) {
                ui.main_movie_top->setPixmap(QPixmap::fromImage(msg));
//                QPixmap p = QPixmap::fromImage(msg);
            }

            void MainWindow::updateRviz_tpfView(const QImage &msg) {
                ui.main_movie_tpf->setPixmap(QPixmap::fromImage(msg));
//                QPixmap p = QPixmap::fromImage(msg);
            }

            void MainWindow::updateMotorDataView() {
              ui.motor_header_sec_lcd->display(motor_data.HEADER_SEC);
              ui.motor_header_nsec_lcd->display(motor_data.HEADER_NSEC);

              ui.motor_Name->setText(QString(motor_data.NAME.c_str()));
              ui.motor_CM->setText(QString(motor_data.CM.c_str()));
              ui.motor_RP->setText(QString(motor_data.RP.c_str()));

//              if(motor_data.DMC_S == true){
//                ui.motor_DMC_S_signal->setPixmap(m_lightimg[1]);
//                ui.main_robotstatus_controller_signal->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.motor_DMC_S_signal->setPixmap(m_lightimg[0]);
//                ui.main_robotstatus_controller_signal->setPixmap(m_lightimg[0]);
//              }

              if(motor_data.FMC_S == true){
                ui.motor_FMC_S_signal->setPixmap(m_lightimg[1]);
              }
              else{
                ui.motor_FMC_S_signal->setPixmap(m_lightimg[0]);
              }

              ui.motor_LM_SPD_lcd->display(motor_data.LM_SPD);
              ui.motor_LW_SPD_lcd->display(motor_data.LW_SPD);
              ui.motor_RM_SPD_lcd->display(motor_data.RM_SPD);
              ui.motor_RW_SPD_lcd->display(motor_data.RW_SPD);
              ui.motor_FM_SPD_lcd->display(motor_data.FM_SPD);
              ui.motor_FW_SPD_lcd->display(motor_data.FW_SPD);
              ui.motor_FM_AGL_lcd->display(motor_data.FM_AGL);
              ui.main_robotstatus_FW_AGL_lcd->display(motor_data.FW_AGL);

            }



            void MainWindow::updateBatteryDataView() {
                /*
              ui.battery_sec_lcd->display(battery_data.HEADER_SEC);
              ui.battery_nsec_lcd->display(battery_data.HEADER_NSEC);
              ui.battery_name->setText(QString(battery_data.NAME.c_str()));

              ui.battery_batterybar->setValue(battery_data.SOC);
              ui.main_robotstatus_batterybar->setValue(battery_data.SOC);
              ui.battery_voltage_lcd->display(battery_data.V);
              ui.battery_ampere_lcd->display(battery_data.A);
              ui.battery_temperature_lcd->display((int)battery_data.TEMP);
              */
            }

            void MainWindow::CtoR_updateJDataView() {


                // Try Again



//              ui.jotstick_header_sec_lcd->display(CtoR_joystick_data.HEADER_SEC);
//              ui.jotstick_header_nsec_lcd->display(CtoR_joystick_data.HEADER_NSEC);
//              ui.joystick_name->setText(QString(CtoR_joystick_data.NAME.c_str()));

//              ui.joystick_LS_X_lcd->display(CtoR_joystick_data.LS_X);
//              ui.joystick_LS_Y_lcd->display(CtoR_joystick_data.LS_Y);

//              if(CtoR_joystick_data.L_T == true){
//                ui.joystick_L_T_signal->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.joystick_L_T_signal->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.L1_BTN == true){
//                ui.joystick_L1_BTN_signal->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.joystick_L1_BTN_signal->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.L2_BTN == true){
//                ui.joystick_L2_BTN_signal->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.joystick_L2_BTN_signal->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.L3_BTN == true){
//                ui.joystick_L3_BTN_signal->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.joystick_L3_BTN_signal->setPixmap(m_lightimg[0]);
//              }

//              ui.joystick_RS_X_lcd->display(CtoR_joystick_data.RS_X);
//              ui.joystick_RS_Y_lcd->display(CtoR_joystick_data.RS_Y);

//              if(CtoR_joystick_data.R_T == true){
//                ui.joystick_R_T_signal->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.joystick_R_T_signal->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.R1_BTN == true){
//                ui.joystick_R1_BTN_signal->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.joystick_R1_BTN_signal->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.R2_BTN == true){
//                ui.joystick_R2_BTN_signal->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.joystick_R2_BTN_signal->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.R3_BTN == true){
//                ui.joystick_R3_BTN_signal->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.joystick_R3_BTN_signal->setPixmap(m_lightimg[0]);
//              }
//
//              ui.command_D_BTN_X_lcd->display(CtoR_joystick_data.D_BTN_X);
//              ui.command_D_BTN_Y_lcd->display(CtoR_joystick_data.D_BTN_Y);

//              if(CtoR_joystick_data.D_BTN_X == 1){
//                  ui.C_img_D_BTN_LEFT->setPixmap(m_lightimg[1]);
//                  ui.C_img_D_BTN_RIGHT->setPixmap(m_lightimg[0]);
//              }
//              else if(CtoR_joystick_data.D_BTN_X == -1){
//                  ui.C_img_D_BTN_LEFT->setPixmap(m_lightimg[0]);
//                  ui.C_img_D_BTN_RIGHT->setPixmap(m_lightimg[1]);
//              }
//              else{
//                  ui.C_img_D_BTN_LEFT->setPixmap(m_lightimg[0]);
//                  ui.C_img_D_BTN_RIGHT->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.D_BTN_Y == 1){
//                  ui.C_img_D_BTN_UP->setPixmap(m_lightimg[1]);
//                  ui.C_img_D_BTN_DOWN->setPixmap(m_lightimg[0]);
//              }
//              else if(CtoR_joystick_data.D_BTN_Y == -1){
//                  ui.C_img_D_BTN_UP->setPixmap(m_lightimg[0]);
//                  ui.C_img_D_BTN_DOWN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                  ui.C_img_D_BTN_UP->setPixmap(m_lightimg[0]);
//                  ui.C_img_D_BTN_DOWN->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.BTN0 == true){ // X button
//                ui.C_label_BTN0->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.C_label_BTN0->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.BTN1 == true){ // O button
//                ui.C_label_BTN1->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.C_label_BTN1->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.BTN2 == true){ //triangle button
//                ui.C_label_BTN2->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.C_label_BTN2->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.BTN3 == true){ //square button
//                ui.C_label_BTN3->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.C_label_BTN3->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.S_BTN == true){ //share button
//                ui.C_label_S_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.C_label_S_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.O_BTN == true){ //button button
//                ui.C_label_O_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.C_label_O_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.PS_BTN == true){ //ps button
//                ui.C_label_PS_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.C_label_PS_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.DMC_BTN == true){ //DMC button
//                ui.C_label_DMC_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.C_label_DMC_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(CtoR_joystick_data.FMC_BTN == true){ //FMC button
//                ui.C_label_FMC_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.C_label_FMC_BTN->setPixmap(m_lightimg[0]);
//              }

            }


            void MainWindow::RtoC_updateJDataView() {
//              ui.lcd_j_sec->display(RtoC_joystick_data.HEADER_SEC);
//              ui.lcd_j_nsec->display(RtoC_joystick_data.HEADER_NSEC);
//              ui.data_j_NAME->setText(QString(RtoC_joystick_data.NAME.c_str()));

//              ui.lcd_LS_X->display(RtoC_joystick_data.LS_X);
//              ui.lcd_LS_Y->display(RtoC_joystick_data.LS_Y);

//              if(RtoC_joystick_data.L_T == true){
//                ui.label_L_T->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_L_T->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.L1_BTN == true){
//                ui.label_L1_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_L1_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.L2_BTN == true){
//                ui.label_L2_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_L2_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.L3_BTN == true){
//                ui.label_L3_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_L3_BTN->setPixmap(m_lightimg[0]);
//              }

//              ui.lcd_RS_X->display(RtoC_joystick_data.RS_X);
//              ui.lcd_RS_Y->display(RtoC_joystick_data.RS_Y);

//              if(RtoC_joystick_data.R_T == true){
//                ui.label_R_T->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_R_T->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.R1_BTN == true){
//                ui.label_R1_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_R1_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.R2_BTN == true){
//                ui.label_R2_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_R2_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.R3_BTN == true){
//                ui.label_R3_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_R3_BTN->setPixmap(m_lightimg[0]);
//              }

//              ui.lcd_D_BTN_X->display(RtoC_joystick_data.D_BTN_X);
//              ui.lcd_D_BTN_Y->display(RtoC_joystick_data.D_BTN_Y);

//              if(RtoC_joystick_data.BTN0 == true){ // X button
//                ui.label_BTN0->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_BTN0->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.BTN1 == true){ // O button
//                ui.label_BTN1->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_BTN1->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.BTN2 == true){ //triangle button
//                ui.label_BTN2->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_BTN2->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.BTN3 == true){ //square button
//                ui.label_BTN3->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_BTN3->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.S_BTN == true){ //share button
//                ui.label_S_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_S_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.O_BTN == true){ //button button
//                ui.label_O_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_O_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.PS_BTN == true){ //ps button
//                ui.label_PS_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_PS_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.DMC_BTN == true){ //DMC button
//                ui.label_DMC_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_DMC_BTN->setPixmap(m_lightimg[0]);
//              }

//              if(RtoC_joystick_data.FMC_BTN == true){ //FMC button
//                ui.label_FMC_BTN->setPixmap(m_lightimg[1]);
//              }
//              else{
//                ui.label_FMC_BTN->setPixmap(m_lightimg[0]);
//              }

            }


            /*****************************************************************************
            ** Implementation [Menu]
            *****************************************************************************/

            void MainWindow::on_actionAbout_triggered() {
                QMessageBox::about(this, tr("About ..."),tr("<h2>PACKAGE_NAME Test Program 0.10</h2><p>Copyright Yujin Robot</p><p>This package needs an about description.</p>"));
            }

            /*****************************************************************************
            ** Implementation [Configuration]
            *****************************************************************************/

            void MainWindow::ReadSettings() {
                QSettings settings("Qt-Ros Package", "kmu_gui");
                restoreGeometry(settings.value("geometry").toByteArray());
                restoreState(settings.value("windowState").toByteArray());
                QString master_url = settings.value("master_url",QString("http://192.168.1.2:11311/")).toString();
                QString host_url = settings.value("host_url", QString("192.168.1.3")).toString();
                //QString topic_name = settings.value("topic_name", QString("/chatter")).toString();
                ui.comm_connect_line_edit_master->setText(master_url);
                ui.comm_connect_line_edit_host->setText(host_url);
                //ui.line_edit_topic->setText(topic_name);
                bool remember = settings.value("remember_settings", false).toBool();
                ui.comm_checkbox_remember_settings->setChecked(remember);
                bool checked = settings.value("use_environment_variables", false).toBool();
                ui.comm_checkbox_use_environment->setChecked(checked);
                if ( checked ) {
                    ui.comm_connect_line_edit_master->setEnabled(false);
                    ui.comm_connect_line_edit_host->setEnabled(false);
                    //ui.line_edit_topic->setEnabled(false);
                }
            }

            void MainWindow::WriteSettings() {
                QSettings settings("Qt-Ros Package", "kmu_gui");
                settings.setValue("master_url",ui.comm_connect_line_edit_master->text());
                settings.setValue("host_url",ui.comm_connect_line_edit_host->text());
                //settings.setValue("topic_name",ui.line_edit_topic->text());
                settings.setValue("use_environment_variables",QVariant(ui.comm_checkbox_use_environment->isChecked()));
                settings.setValue("geometry", saveGeometry());
                settings.setValue("windowState", saveState());
                settings.setValue("remember_settings",QVariant(ui.comm_checkbox_remember_settings->isChecked()));
            }

            void MainWindow::closeEvent(QCloseEvent *event) {
                WriteSettings();
                QMainWindow::closeEvent(event);
            }

        }  // namespace kmu_gui
